# Run program with 

java -jar MasterThesis.jar example_function.pla example_function.txt


# Or by double clicking one of bat files